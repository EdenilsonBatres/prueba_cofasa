<header>
    <div class="titulo">
        <h2>Prueba Técnica </h2>
    </div>

</header>